import xml.etree.ElementTree as ET
import os
import syslog
import logging
import pragma.utils
import subprocess

from pragma.repository.processor import process_file


class BaseRepository(object):
    def __init__(self, settings={}):
        """
        vcdb is a path to vcdb.json

        vcdb is a dict of vc in this format
        {'vcname': '/path/to/meta.xml', ...}
        """
        super(BaseRepository, self).__init__()
        self.settings = settings
        try:
            self.repo = self.settings["repository_dir"]
        except KeyError:
            self.abort('Check repository_settings{} in configuration file. Missing  \"repository_dir\".' )

        # vcdb filename 
        try:
            self.vcdbFilename = self.settings["vcdb_filename"]
        except KeyError:
            self.vcdbFilename = 'vcdb.txt' 

        self.vcdbFile = None
        self.vcdb = {}

	logging.basicConfig()
	self.logger = logging.getLogger(self.__module__)


    def abort(self, msg):
        syslog.syslog(syslog.LOG_ERR, msg)
        raise pragma.utils.CommandError(msg)


    def listRepository(self):
        """ Returns an array of names of available virtual images """
        result = []
        with open(self.vcdbFile, 'r') as vcdbFile:
            for line in vcdbFile:
               name, xmlpath = line.split(',')
               result.append(name)
        return result

    def download(self, remote_path, local_path):
        """
        Download file from remote_path to local_path
        Using wget and curl because urllib and urllib2 don't seem to be able
        to complete big file transfers (at least from Google drive)
        """

        # Create directories if neccesary
        local_dir = os.path.dirname(local_path)
        if not os.path.exists(local_dir):
            os.makedirs(local_dir)

        # log file for wget or curl messages
        log = "/tmp/pragma_boot.download.log"

        wget = pragma.utils.which("xwget")
        # using wget 
        if wget : 
            subprocess.check_call([wget, "--append-output=%s" % log, "-S", "-O", local_path, remote_path])
        # using curl 
        else:     
            curl = pragma.utils.which("curl")
            if curl is None:
                self.abort ('Cannot find wget or curl for downloading files.')
            subprocess.check_call("%s --retry 5 -L --stderr - -o %s %s 2>&1  1>>%s" % (curl, local_path, remote_path, log), shell=True)

        self.logger.info("Downloading %s to %s ... See %s for details" % (remote_path, local_path, log))

        if not os.path.isfile(local_path):
            self.abort ('Error downloading  %s. See %s for details' % (local_path, log))


    def getLocalFilePath(self, fname):
        """ returns full path to a file in a local repository """
        return os.path.join(self.repo, fname)


    def getRemoteFilePath(self, fname):
        """ returns full path to a file in a remote repository """
        try:
           return os.path.join(self.repository_url, fname)
        except AttributeError:
           # repository_url is not defined in configuration file
           return None

    def checkVcdbFile (self):
        """ check if the vcdb file exists, download if needed """
        self.vcdbFile = os.path.join(self.repo, self.vcdbFilename)
        if not os.path.isfile(self.vcdbFile):
            lpath = self.getLocalFilePath(self.vcdbFilename)
            rpath = self.getRemoteFilePath(self.vcdbFilename)
            if not rpath:
                self.abort ('File %s does not exist. Define repository_url in configuration file to enable its download.' % lpath)
            self.download(rpath, lpath)

        with open(self.vcdbFile, 'r') as vcdbFile:
            for line in vcdbFile:
                name, path = line.strip().split(',')
                self.vcdb[name] = self.getLocalFilePath(path)

        print "DEBUG self.vcdb:", self.vcdb

    def getVmInfo(self, name):
        """ Check if virtual images specified by name exists in the database
            return xml object describing it and the base directory for the image
        """
        if name not in self.vcdb:
           self.abort('Virtual image %s  is not found.' % name)

        xmlinfo =  ET.parse(self.vcdb[name])
        dirpath = os.path.dirname(self.vcdb[name])
        
        return (xmlinfo, dirpath) 

    #def get_vc(self, vcname):
    #    if vcname not in self.vc_file:
    #        lpath = self.getLocalFilePath(self.vcdb[vcname])
    #        rpath = self.getRemoteFilePath(self.vcdb[vcname])
    #        #self.download(rpath,lpath)
    #        self.vc_file[vcname] = lpath
#
#        return ET.parse(self.vc_file[vcname])

#    def get_vc_file(self, name):
#        return self.vc_file[name]

    def is_downloaded(self):
        raise NotImplementedError

    def download_vc(self, vcname):
        """Download VC to repository cache"""
        raise NotImplementedError

    def delete_vc(self, vcname):
        """Delete VC from repository cache if exists"""
        raise NotImplementedError

    def process_vc(self, vcname):
        base_dir = os.path.dirname(os.path.join(self.repo, self.vcdb[vcname]))
        for f in self.get_vc(vcname).findall("./files/file"):
            process_file(base_dir, f)

    def download_and_process_vc(self, vcname, vc_in):
        self.download_vc(vcname, vc_in)
        self.process_vc(vcname)

    def clear_cache(self):
        """Clear repository cache entirely"""
        raise NotImplementedError
