from pragma.repository import BaseRepository
import logging
import os


class Http(BaseRepository):

    def __init__(self, settings):
        super(Http, self).__init__(settings)
        try:
            self.repository_url = self.settings["repository_url"]
        except KeyError:
            self.abort('Check repository_settings{} in configuration file. Missing  \"repository_url\".' )
        self.checkVcdbFile()


    def download_vc(self, vcname, vc_in):
        """
        Download all files specified in vc definition
        """
        relative_dir = os.path.dirname(self.get_vcdb()[vcname])

        for filename in self.get_vc(vcname).findall("./files/file/part"):
            remote_path = os.path.join(self.repository_url, relative_dir, filename.text)
            local_path = os.path.join(self.repo, relative_dir, filename.text)
            Http.download(remote_path, local_path)

        for node in vc_in.xml.findall(".//disk/source[@type='network']/../../../.."):
            node_type = node.tag
            filename = "%s_%s.img" % (relative_dir, node_type)
            local_path = os.path.join(self.repo, relative_dir, filename)
            if not(os.path.exists(local_path)):
                host = node.find(".//host").attrib
                source = node.find(".//source").attrib
                remote_path = "%s://%s:%s/%s" % (source["protocol"], host["name"], host["port"], source["name"])
                Http.download(remote_path, local_path)
            new_node = node.find(".//source")
            new_node.tag = "source"
            new_node.attrib = {"file": local_path}


    # TODO: Make delete_vc handle either unprocessed and
    # processed VC
    # def delete_vc(self, vcname):
    #     for path in self.get_parsed_vc(vcname):
    #         os.remove(path)
